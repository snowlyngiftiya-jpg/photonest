"""Aggregation pipelines used by the dashboard and the Mongo query explorer.

Every chart on the dashboard is one named pipeline below. The explorer shows the exact
pipeline JSON next to its result so each MongoDB concept can be demonstrated live.
"""
import datetime as dt

import geo

UNWIND_MEDIA = {"$unwind": "$media"}

CATALOG = [
    {
        "key": "category_mix", "title": "Shoots & revenue by category", "chart": "bar",
        "concept": "$group + $sum + $sort",
        "desc": "Groups shoots by category and totals the booked package price.",
        "collection": "shoots",
        "pipeline": [
            {"$group": {"_id": "$category", "shoots": {"$sum": 1}, "revenue": {"$sum": "$package.price"}}},
            {"$sort": {"shoots": -1}},
        ],
        "label": "_id", "values": ["shoots", "revenue"],
    },
    {
        "key": "revenue_month", "title": "Collected revenue per month", "chart": "line",
        "concept": "$unwind on embedded payments[] + $dateToString",
        "desc": "Unwinds the embedded payments array, keeps paid entries and buckets them by month.",
        "collection": "shoots",
        "pipeline": [
            {"$unwind": "$payments"},
            {"$match": {"payments.status": "paid"}},
            {"$group": {"_id": {"$dateToString": {"format": "%Y-%m", "date": "$payments.paid_at"}},
                        "collected": {"$sum": "$payments.amount"}, "payments": {"$sum": 1}}},
            {"$sort": {"_id": 1}},
        ],
        "label": "_id", "values": ["collected"],
    },
    {
        "key": "photographer_board", "title": "Photographer leaderboard", "chart": "bar",
        "concept": "$group + $size on embedded media[]",
        "desc": "Counts shoots, total embedded media items (via $size) and revenue per photographer.",
        "collection": "shoots",
        "pipeline": [
            {"$group": {"_id": "$photographer.name", "shoots": {"$sum": 1},
                        "media_items": {"$sum": {"$size": {"$ifNull": ["$media", []]}}},
                        "revenue": {"$sum": "$package.price"}}},
            {"$sort": {"revenue": -1}},
        ],
        "label": "_id", "values": ["media_items", "shoots"],
    },
    {
        "key": "camera_usage", "title": "Camera bodies used (from EXIF)", "chart": "doughnut",
        "concept": "$unwind + $match on embedded exif{}",
        "desc": "EXIF captured at upload time lives inside each embedded media document.",
        "collection": "shoots",
        "pipeline": [
            UNWIND_MEDIA,
            {"$match": {"media.kind": "image", "media.exif.camera": {"$exists": True}}},
            {"$group": {"_id": "$media.exif.camera", "photos": {"$sum": 1}, "avg_iso": {"$avg": "$media.exif.iso"}}},
            {"$sort": {"photos": -1}},
        ],
        "label": "_id", "values": ["photos"],
    },
    {
        "key": "tag_cloud", "title": "Top tags across all photos", "chart": "bar",
        "concept": "double $unwind (media[] then tags[])",
        "desc": "Unwinds two levels of embedding to count tag usage.",
        "collection": "shoots",
        "pipeline": [
            UNWIND_MEDIA,
            {"$unwind": "$media.tags"},
            {"$group": {"_id": "$media.tags", "uses": {"$sum": 1}}},
            {"$sort": {"uses": -1}},
            {"$limit": 10},
        ],
        "label": "_id", "values": ["uses"],
    },
    {
        "key": "rating_dist", "title": "Photo rating distribution", "chart": "bar",
        "concept": "$unwind + $group on a numeric embedded field",
        "desc": "How the culling stars (0 to 5) are spread over all images.",
        "collection": "shoots",
        "pipeline": [
            UNWIND_MEDIA,
            {"$match": {"media.kind": "image"}},
            {"$group": {"_id": "$media.rating", "photos": {"$sum": 1}}},
            {"$sort": {"_id": 1}},
        ],
        "label": "_id", "values": ["photos"],
    },
    {
        "key": "iso_buckets", "title": "ISO usage buckets", "chart": "bar",
        "concept": "$bucket",
        "desc": "Buckets the embedded EXIF ISO values into low, medium and high light ranges.",
        "collection": "shoots",
        "pipeline": [
            UNWIND_MEDIA,
            {"$match": {"media.kind": "image", "media.exif.iso": {"$exists": True}}},
            {"$bucket": {"groupBy": "$media.exif.iso", "boundaries": [0, 200, 800, 3200, 102400],
                         "default": "other", "output": {"photos": {"$sum": 1}}}},
        ],
        "label": "_id", "values": ["photos"],
    },
    {
        "key": "storage_split", "title": "Storage tiering: inline vs GridFS", "chart": "doughnut",
        "concept": "$group on media.storage with $sum of size",
        "desc": "Small images are embedded as base64 in the shoot document, large files and videos go to GridFS.",
        "collection": "shoots",
        "pipeline": [
            UNWIND_MEDIA,
            {"$group": {"_id": "$media.storage", "items": {"$sum": 1}, "bytes": {"$sum": "$media.size"}}},
            {"$sort": {"items": -1}},
        ],
        "label": "_id", "values": ["items"],
    },
    {
        "key": "status_funnel", "title": "Shoot pipeline funnel", "chart": "bar",
        "concept": "$group on status",
        "desc": "How many shoots sit in each workflow stage.",
        "collection": "shoots",
        "pipeline": [{"$group": {"_id": "$status", "shoots": {"$sum": 1}}}, {"$sort": {"shoots": -1}}],
        "label": "_id", "values": ["shoots"],
    },
    {
        "key": "weekday", "title": "Busiest weekdays", "chart": "bar",
        "concept": "$dayOfWeek date operator",
        "desc": "1 = Sunday … 7 = Saturday.",
        "collection": "shoots",
        "pipeline": [{"$group": {"_id": {"$dayOfWeek": "$shoot_date"}, "shoots": {"$sum": 1}}}, {"$sort": {"_id": 1}}],
        "label": "_id", "values": ["shoots"],
    },
    {
        "key": "dues", "title": "Outstanding dues by client", "chart": "bar",
        "concept": "$unwind payments[] + $match pending",
        "desc": "Pending embedded payment entries summed per embedded client name.",
        "collection": "shoots",
        "pipeline": [
            {"$unwind": "$payments"},
            {"$match": {"payments.status": "pending"}},
            {"$group": {"_id": "$client.name", "due": {"$sum": "$payments.amount"}, "entries": {"$sum": 1}}},
            {"$sort": {"due": -1}},
            {"$limit": 8},
        ],
        "label": "_id", "values": ["due"],
    },
    {
        "key": "favourites", "title": "Most favourited shoots", "chart": "bar",
        "concept": "$unwind + $match on boolean + $limit",
        "desc": "Shoots ranked by the number of photos starred as favourite.",
        "collection": "shoots",
        "pipeline": [
            UNWIND_MEDIA,
            {"$match": {"media.favorite": True}},
            {"$group": {"_id": "$title", "favourites": {"$sum": 1}}},
            {"$sort": {"favourites": -1}},
            {"$limit": 6},
        ],
        "label": "_id", "values": ["favourites"],
    },
    {
        "key": "city_spread", "title": "Shoots by city", "chart": "bar",
        "concept": "$group on embedded venue.city",
        "desc": "Geographic spread using the embedded venue sub-document.",
        "collection": "shoots",
        "pipeline": [{"$group": {"_id": "$venue.city", "shoots": {"$sum": 1}}}, {"$sort": {"shoots": -1}}],
        "label": "_id", "values": ["shoots"],
    },
]
BY_KEY = {c["key"]: c for c in CATALOG}


def _scalar(db, pipeline, field, default=0):
    row = next(iter(db.shoots.aggregate(pipeline)), None)
    return (row or {}).get(field, default) or default


def kpis(db) -> dict:
    sum_pay = lambda status: _scalar(db, [  # noqa: E731
        {"$unwind": "$payments"}, {"$match": {"payments.status": status}},
        {"$group": {"_id": None, "t": {"$sum": "$payments.amount"}}}], "t")
    media_row = next(iter(db.shoots.aggregate([
        UNWIND_MEDIA, {"$group": {"_id": None, "items": {"$sum": 1}, "bytes": {"$sum": "$media.size"},
                                  "favs": {"$sum": {"$cond": ["$media.favorite", 1, 0]}}}}])), {})
    avg = _scalar(db, [UNWIND_MEDIA, {"$match": {"media.rating": {"$gt": 0}}},
                       {"$group": {"_id": None, "a": {"$avg": "$media.rating"}}}], "a")
    return {
        "shoots": db.shoots.count_documents({}),
        "upcoming": db.shoots.count_documents({"shoot_date": {"$gte": dt.datetime.utcnow()}}),
        "media": media_row.get("items", 0), "favourites": media_row.get("favs", 0),
        "bytes": media_row.get("bytes", 0), "avg_rating": round(avg, 2),
        "collected": sum_pay("paid"), "pending": sum_pay("pending"),
        "clients": db.clients.count_documents({}), "photographers": db.photographers.count_documents({}),
        "equipment": db.equipment.count_documents({}),
    }


def run_all(db) -> dict:
    charts = []
    for c in CATALOG:
        rows = list(db[c["collection"]].aggregate(c["pipeline"]))
        charts.append({**c, "rows": rows})
    return {"kpis": kpis(db), "charts": charts}


def nearby(store, lat: float, lng: float, km: float, limit=25) -> list[dict]:
    """Shoots within `km` kilometres. Uses $geoNear (2dsphere) on MongoDB; haversine fallback in demo mode."""
    proj = {"title": 1, "category": 1, "venue": 1, "location": 1, "shoot_date": 1, "status": 1}
    if store.mode == "mongodb":
        pipe = [{"$geoNear": {"near": {"type": "Point", "coordinates": [lng, lat]}, "distanceField": "dist_m",
                              "maxDistance": km * 1000, "spherical": True}},
                {"$project": {**proj, "dist_m": 1}}, {"$limit": limit}]
        return [{**d, "dist_km": round(d["dist_m"] / 1000, 2)} for d in store.db.shoots.aggregate(pipe)]
    rows = []
    for d in store.db.shoots.find({"location": {"$exists": True}}, proj):
        c = d["location"]["coordinates"]
        dist = geo.haversine_km(lat, lng, c[1], c[0])
        if dist <= km:
            rows.append({**d, "dist_km": round(dist, 2)})
    return sorted(rows, key=lambda r: r["dist_km"])[:limit]


def conflicts(db, when: dt.datetime, equipment_ids: list[str], photographer_id: str | None, exclude=None) -> list[dict]:
    """Same-day double-bookings of gear or photographer (uses the compound equipment index)."""
    day = when.replace(hour=0, minute=0, second=0, microsecond=0)
    ors = []
    if equipment_ids:
        ors.append({"equipment.id": {"$in": equipment_ids}})
    if photographer_id:
        ors.append({"photographer.id": photographer_id})
    if not ors:
        return []
    q = {"shoot_date": {"$gte": day, "$lt": day + dt.timedelta(days=1)}, "$or": ors}
    if exclude:
        q["_id"] = {"$ne": exclude}
    out = []
    for d in db.shoots.find(q, {"title": 1, "equipment": 1, "photographer": 1, "shoot_date": 1}):
        clash = [e["name"] for e in d.get("equipment", []) if e["id"] in equipment_ids]
        if photographer_id and d.get("photographer", {}).get("id") == photographer_id:
            clash.append(f"photographer {d['photographer']['name']}")
        out.append({"id": d["_id"], "title": d["title"], "when": d["shoot_date"], "clash": clash})
    return out


def equipment_utilisation(db) -> dict:
    rows = db.shoots.aggregate([
        {"$unwind": "$equipment"},
        {"$group": {"_id": "$equipment.id", "shoots": {"$sum": 1}, "last_used": {"$max": "$shoot_date"}}},
    ])
    return {r["_id"]: r for r in rows}
