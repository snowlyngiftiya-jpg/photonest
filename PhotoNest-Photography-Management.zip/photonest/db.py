"""MongoDB connection, GridFS and index setup.

Connects to a real MongoDB (local or Atlas) via MONGODB_URI. If the server is not
reachable (or USE_MOCK_DB=1) it falls back to an in-memory mongomock database so the
project always runs for a demo. The dashboard shows which mode is active.
"""
import os
from dataclasses import dataclass

import gridfs
from pymongo import ASCENDING, DESCENDING, GEOSPHERE, MongoClient


@dataclass
class Store:
    db: object
    fs: object
    mode: str          # "mongodb" or "memory"
    error: str | None  # why we fell back, if we did


def connect() -> Store:
    uri = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
    name = os.getenv("MONGODB_DB", "photonest")
    err = None
    if os.getenv("USE_MOCK_DB", "0") != "1":
        try:
            client = MongoClient(uri, serverSelectionTimeoutMS=3000)
            client.admin.command("ping")
            db = client[name]
            return Store(db, gridfs.GridFS(db), "mongodb", None)
        except Exception as exc:  # noqa: BLE001
            err = f"{type(exc).__name__}: {str(exc)[:160]}"
    import mongomock
    from mongomock import gridfs as mock_gridfs

    mock_gridfs.enable_gridfs_integration()
    db = mongomock.MongoClient()[name]
    return Store(db, gridfs.GridFS(db), "memory", err)


def ensure_indexes(db) -> None:
    specs = [
        (db.shoots, [("slug", ASCENDING)], {"unique": True}),
        (db.shoots, [("location", GEOSPHERE)], {}),                      # 2dsphere: nearby search
        (db.shoots, [("status", ASCENDING), ("shoot_date", DESCENDING)], {}),
        (db.shoots, [("photographer.id", ASCENDING)], {}),
        (db.shoots, [("client.id", ASCENDING)], {}),
        (db.shoots, [("equipment.id", ASCENDING), ("shoot_date", ASCENDING)], {}),
        (db.shoots, [("media.tags", ASCENDING)], {}),                    # multikey on embedded array
        (db.shoots, [("media.exif.camera", ASCENDING)], {}),
        (db.shoots, [("proof.token", ASCENDING)], {"unique": True}),
        (db.clients, [("email", ASCENDING)], {}),
        (db.photographers, [("email", ASCENDING)], {}),
        (db.equipment, [("name", ASCENDING)], {}),
    ]
    for coll, keys, opts in specs:
        try:
            coll.create_index(keys, **opts)
        except Exception:  # noqa: BLE001  (never block startup on an index)
            pass
