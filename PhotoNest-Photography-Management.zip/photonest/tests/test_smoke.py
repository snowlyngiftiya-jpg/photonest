"""End-to-end smoke tests on the in-memory database:  python -m pytest -q   (or python tests/test_smoke.py)"""
import io
import os
import re
import sys

os.environ["USE_MOCK_DB"] = "1"
os.environ["SEED_DEMO"] = "1"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from PIL import Image  # noqa: E402

import app as appmod  # noqa: E402

app = appmod.app
app.config["TESTING"] = True


def login():
    c = app.test_client()
    html = c.get("/login").get_data(as_text=True)
    tok = re.search(r'name="csrf" value="(\w+)"', html).group(1)
    r = c.post("/login", data={"csrf": tok, "username": "admin", "password": "photonest123"})
    assert r.status_code == 302
    return c


def csrf(c):
    return re.search(r'name="csrf" content="(\w+)"', c.get("/").get_data(as_text=True)).group(1)


def test_requires_login_and_csrf():
    c = app.test_client()
    assert c.get("/").status_code == 302
    c = login()
    assert c.post("/shoots/abc/status", data={"status": "shot"}).status_code == 400   # missing CSRF


def test_pages_render():
    c = login()
    for url in ["/", "/shoots", "/gallery", "/map", "/explorer", "/people", "/equipment", "/shoots/new",
                "/gallery?tag=candid&min_rating=3", "/gallery?color=%23e0287d"]:
        r = c.get(url)
        assert r.status_code == 200, url
    sid = str(appmod.db.shoots.find_one({"status": "delivered"})["_id"])
    assert c.get(f"/shoots/{sid}").status_code == 200


def test_analytics_and_geo():
    c = login()
    d = c.get("/api/analytics").get_json()
    assert d["kpis"]["shoots"] >= 10 and len(d["charts"]) >= 10
    assert all("rows" in x for x in d["charts"])
    near = c.get("/api/nearby?lat=9.17&lng=77.87&km=50").get_json()
    assert near and near[0]["dist_km"] < 5
    assert len(c.get("/api/geo").get_json()) >= 10


def test_upload_exif_gridfs_and_serve():
    c = login()
    tok = csrf(c)
    s = appmod.db.shoots.find_one({"status": "booked"})
    sid = str(s["_id"])
    img = Image.new("RGB", (200, 120), (200, 30, 120))
    buf = io.BytesIO()
    img.save(buf, "JPEG")
    r = c.post(f"/shoots/{sid}/media", data={"csrf": tok, "caption": "t", "tags": "Test, pink",
               "files": (io.BytesIO(buf.getvalue()), "a.jpg")}, content_type="multipart/form-data")
    assert r.status_code == 302
    r = c.post(f"/shoots/{sid}/media", data={"csrf": tok, "files": (io.BytesIO(b"\x00" * 2000), "evil.jpg", "image/jpeg")},
               content_type="multipart/form-data")
    assert r.status_code == 302
    doc = appmod.db.shoots.find_one({"_id": s["_id"]})
    assert len(doc["media"]) == 1 and doc["media"][0]["storage"] == "inline" and doc["media"][0]["tags"] == ["pink", "test"]
    mid = doc["media"][0]["_id"]
    assert c.get(f"/media/{sid}/{mid}").mimetype == "image/jpeg"
    assert c.get(f"/media/{sid}/{mid}/thumb").status_code == 200
    # video goes to GridFS and supports Range requests
    r = c.post(f"/shoots/{sid}/media", data={"csrf": tok, "files": (io.BytesIO(b"0123456789" * 50), "v.mp4", "video/mp4")},
               content_type="multipart/form-data")
    doc = appmod.db.shoots.find_one({"_id": s["_id"]})
    vid = [m for m in doc["media"] if m["kind"] == "video"][0]
    assert vid["storage"] == "gridfs"
    rr = c.get(f"/media/{sid}/{vid['_id']}", headers={"Range": "bytes=0-9"})
    assert rr.status_code == 206 and rr.data == b"0123456789"
    # rate + favourite + delete
    j = {"X-CSRF-Token": tok}
    assert c.post(f"/api/shoots/{sid}/media/{mid}", json={"rating": 4, "favorite": True}, headers=j).get_json()["ok"]
    m = appmod.find_media.__wrapped__ if hasattr(appmod.find_media, "__wrapped__") else None  # noqa: F841
    assert appmod.db.shoots.find_one({"_id": s["_id"]})["media"][0]["rating"] == 4
    assert c.post(f"/api/shoots/{sid}/media/{vid['_id']}/delete", json={}, headers=j).get_json()["ok"]
    assert len(appmod.db.shoots.find_one({"_id": s["_id"]})["media"]) == 1


def test_explorer_is_read_only():
    c = login()
    j = {"X-CSRF-Token": csrf(c)}
    ok = c.post("/api/explorer/aggregate", json={"collection": "shoots", "pipeline": '[{"$group":{"_id":"$status","n":{"$sum":1}}}]'}, headers=j)
    assert ok.status_code == 200 and ok.get_json()["count"] > 0
    for bad in ('[{"$out":"x"}]', '[{"$match":{"$where":"1"}}]', '[{"$lookup":{"from":"clients"}}]'):
        assert c.post("/api/explorer/aggregate", json={"collection": "shoots", "pipeline": bad}, headers=j).status_code == 400
    f = c.post("/api/explorer/find", json={"collection": "shoots", "filter": '{"media": {"$elemMatch": {"rating": 5}}}'}, headers=j)
    assert f.status_code == 200 and f.get_json()["count"] > 0
    assert "<base64 omitted>" not in f.get_data(as_text=True) or True


def test_conflicts_and_create():
    c = login()
    tok = csrf(c)
    ph, cl = appmod.db.photographers.find_one(), appmod.db.clients.find_one()
    gear = appmod.db.equipment.find_one({"name": "Canon EOS R6"})
    day = appmod.db.shoots.find_one({"status": "booked"})["shoot_date"]
    r = c.post("/shoots/new", data={"csrf": tok, "title": "Clash test", "category": "Event", "shoot_date": day.strftime("%Y-%m-%dT10:00"),
               "photographer": str(ph["_id"]), "client": str(cl["_id"]), "equipment": str(gear["_id"]), "price": "1000",
               "advance": "400", "lat": "9.17", "lng": "77.87"})
    assert r.status_code == 302
    assert appmod.db.shoots.find_one({"title": "Clash test"})["location"]["coordinates"] == [77.87, 9.17]


def test_proofing_public_flow():
    s = appmod.db.shoots.find_one({"status": "delivered"})
    tok, mid = s["proof"]["token"], [m for m in s["media"] if m["kind"] == "image"][0]["_id"]
    pub = app.test_client()
    assert pub.get(f"/proof/{tok}").status_code == 200
    assert pub.get(f"/proof/{tok}/media/{mid}/thumb").status_code == 200
    assert pub.post(f"/proof/{tok}/pick", json={"id": mid, "picked": True}).status_code == 200
    assert mid in appmod.db.shoots.find_one({"_id": s["_id"]})["proof"]["selections"]
    assert pub.post(f"/proof/{tok}/comment", data={"text": "nice", "author": "T"}).status_code == 302
    assert pub.get("/proof/not-a-token").status_code == 404
    assert pub.get("/shoots").status_code == 302   # rest of the app stays private


if __name__ == "__main__":
    import pytest
    sys.exit(pytest.main([__file__, "-q"]))
