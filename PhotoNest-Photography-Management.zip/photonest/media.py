"""Media ingestion: validation, EXIF extraction, thumbnails, palette, perceptual hash,
and smart storage tiering (inline base64 in the embedded document vs GridFS)."""
import base64
import datetime as dt
import io
import mimetypes
import os
import re
import uuid

from PIL import ExifTags, Image, ImageOps

IMAGE_MIMES = {"image/jpeg", "image/png", "image/webp", "image/gif"}
VIDEO_MIMES = {"video/mp4", "video/webm", "video/quicktime"}
INLINE_IMAGE_LIMIT = int(os.getenv("INLINE_IMAGE_LIMIT", 2 * 1024 * 1024))   # 2 MB per image
INLINE_DOC_BUDGET = int(os.getenv("INLINE_DOC_BUDGET", 6 * 1024 * 1024))     # 6 MB per shoot doc
MAX_VIDEO = int(os.getenv("MAX_VIDEO_BYTES", 60 * 1024 * 1024))


class MediaError(ValueError):
    pass


def _num(v):
    try:
        return float(v)
    except Exception:  # noqa: BLE001
        return None


def _dms(vals, ref):
    d, m, s = (float(x) for x in vals)
    out = d + m / 60 + s / 3600
    return -out if ref in ("S", "W") else out


def read_exif(img: Image.Image) -> tuple[dict, dict | None]:
    """Return (exif summary, GeoJSON Point or None)."""
    info, point = {}, None
    try:
        ex = img.getexif()
        if not ex:
            return info, None
        base = {ExifTags.TAGS.get(k, k): v for k, v in ex.items()}
        sub = {ExifTags.TAGS.get(k, k): v for k, v in ex.get_ifd(0x8769).items()}
        make, model = str(base.get("Make", "")).strip(), str(base.get("Model", "")).strip()
        if model:
            info["camera"] = model if make and model.startswith(make) else f"{make} {model}".strip()
        if sub.get("LensModel"):
            info["lens"] = str(sub["LensModel"]).strip()
        if sub.get("ISOSpeedRatings") is not None:
            iso = sub["ISOSpeedRatings"]
            info["iso"] = int(iso[0] if isinstance(iso, (tuple, list)) else iso)
        if _num(sub.get("FNumber")):
            info["aperture"] = round(_num(sub["FNumber"]), 1)
        if _num(sub.get("ExposureTime")):
            t = _num(sub["ExposureTime"])
            info["shutter"] = f"1/{round(1 / t)}s" if 0 < t < 1 else f"{t:g}s"
        if _num(sub.get("FocalLength")):
            info["focal_length"] = round(_num(sub["FocalLength"]))
        taken = sub.get("DateTimeOriginal") or base.get("DateTime")
        if taken:
            try:
                info["taken_at"] = dt.datetime.strptime(str(taken), "%Y:%m:%d %H:%M:%S")
            except ValueError:
                pass
        gps = {ExifTags.GPSTAGS.get(k, k): v for k, v in ex.get_ifd(0x8825).items()}
        if gps.get("GPSLatitude") and gps.get("GPSLongitude"):
            lat = _dms(gps["GPSLatitude"], gps.get("GPSLatitudeRef"))
            lng = _dms(gps["GPSLongitude"], gps.get("GPSLongitudeRef"))
            point = {"type": "Point", "coordinates": [round(lng, 6), round(lat, 6)]}
    except Exception:  # noqa: BLE001
        pass
    return info, point


def average_hash(img: Image.Image) -> str:
    g = img.convert("L").resize((8, 8), Image.LANCZOS)
    px = list(g.getdata())
    avg = sum(px) / 64
    bits = "".join("1" if p >= avg else "0" for p in px)
    return f"{int(bits, 2):016x}"


def hamming(a: str, b: str) -> int:
    return bin(int(a, 16) ^ int(b, 16)).count("1")


def palette(img: Image.Image, n=3) -> list[str]:
    small = img.convert("RGB").resize((96, 96))
    q = small.quantize(colors=6, method=Image.MEDIANCUT)
    pal = q.getpalette()[: 6 * 3]
    counts = sorted(q.getcolors(), reverse=True)[:n]
    return ["#%02x%02x%02x" % tuple(pal[i * 3: i * 3 + 3]) for _, i in counts]


def color_distance(h1: str, h2: str) -> float:
    a = [int(h1[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(h2[i:i + 2], 16) for i in (1, 3, 5)]
    return sum((x - y) ** 2 for x, y in zip(a, b)) ** 0.5


def _data_url(raw: bytes, mime: str) -> str:
    return f"data:{mime};base64,{base64.b64encode(raw).decode()}"


def parse_tags(text: str) -> list[str]:
    return sorted({t.strip().lower().lstrip("#") for t in re.split(r"[,\n]", text or "") if t.strip()})[:12]


def inline_bytes_used(shoot: dict) -> int:
    return sum(m.get("size", 0) for m in shoot.get("media", []) if m.get("storage") == "inline")


def ingest(store, shoot: dict, raw: bytes, filename: str, mime: str | None, caption="", tags=None,
           camera_fallback: str | None = None, location: dict | None = None) -> dict:
    """Validate + enrich an uploaded file and return the embedded media document."""
    mime = (mime or mimetypes.guess_type(filename)[0] or "").lower()
    if mime == "image/jpg":
        mime = "image/jpeg"
    doc = {
        "_id": uuid.uuid4().hex[:12], "filename": os.path.basename(filename)[:120], "caption": caption[:200],
        "mime": mime, "size": len(raw), "tags": tags or [], "rating": 0, "favorite": False,
        "uploaded_at": dt.datetime.utcnow(), "location": location,
    }
    if mime in IMAGE_MIMES:
        try:
            img = Image.open(io.BytesIO(raw))
            img.load()
        except Exception as exc:  # noqa: BLE001
            raise MediaError(f"{filename}: not a valid image") from exc
        exif, gps = read_exif(img)
        if camera_fallback and "camera" not in exif:
            exif["camera"] = camera_fallback
        view = ImageOps.exif_transpose(img).convert("RGB")
        thumb = view.copy()
        thumb.thumbnail((420, 420))
        buf = io.BytesIO()
        thumb.save(buf, "JPEG", quality=72)
        doc.update(
            kind="image", exif=exif, width=view.width, height=view.height,
            thumb=_data_url(buf.getvalue(), "image/jpeg"), palette=palette(view), phash=average_hash(view),
            location=location or gps,
        )
        if len(raw) <= INLINE_IMAGE_LIMIT and inline_bytes_used(shoot) + len(raw) <= INLINE_DOC_BUDGET:
            doc.update(storage="inline", data_url=_data_url(raw, mime))
        else:
            doc.update(storage="gridfs", gridfs_id=store.fs.put(raw, filename=doc["filename"], contentType=mime))
    elif mime in VIDEO_MIMES:
        if len(raw) > MAX_VIDEO:
            raise MediaError(f"{filename}: video larger than {MAX_VIDEO // 1024 // 1024} MB")
        doc.update(kind="video", exif={}, storage="gridfs",
                   gridfs_id=store.fs.put(raw, filename=doc["filename"], contentType=mime))
    else:
        raise MediaError(f"{filename}: unsupported type '{mime or 'unknown'}'")
    return doc


def external_link(url: str, caption: str, tags: list[str]) -> dict:
    """Embed a YouTube/Vimeo link, a direct video URL or a direct image URL (no binary stored)."""
    if not re.match(r"^https?://", url or ""):
        raise MediaError("Link must start with http:// or https://")
    yt = re.search(r"(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/)([\w-]{11})", url)
    doc = {"_id": uuid.uuid4().hex[:12], "filename": url[:120], "caption": caption[:200], "mime": "", "size": 0,
           "tags": tags, "rating": 0, "favorite": False, "uploaded_at": dt.datetime.utcnow(),
           "storage": "external", "exif": {}, "location": None}
    if yt:
        doc.update(kind="video", url=f"https://www.youtube-nocookie.com/embed/{yt.group(1)}", embed=True,
                   thumb=f"https://i.ytimg.com/vi/{yt.group(1)}/hqdefault.jpg")
    elif re.search(r"\.(mp4|webm|mov)(\?|$)", url, re.I):
        doc.update(kind="video", url=url, embed=False)
    elif re.search(r"\.(jpe?g|png|webp|gif)(\?|$)", url, re.I):
        doc.update(kind="image", url=url, thumb=url)
    else:
        raise MediaError("Unsupported link. Use a YouTube link or a direct image/video URL.")
    return doc


def decode_data_url(data_url: str) -> tuple[bytes, str]:
    head, b64 = data_url.split(",", 1)
    return base64.b64decode(b64), head[5:].split(";")[0]


def find_duplicates(media: list[dict], max_distance=5) -> list[dict]:
    imgs = [m for m in media if m.get("kind") == "image" and m.get("phash")]
    out = []
    for i, a in enumerate(imgs):
        for b in imgs[i + 1:]:
            d = hamming(a["phash"], b["phash"])
            if d <= max_distance:
                out.append({"a": a["_id"], "b": b["_id"], "distance": d})
    return out
