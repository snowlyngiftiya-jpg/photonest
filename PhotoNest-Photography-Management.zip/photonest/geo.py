"""Geo helpers: haversine distance and a dependency-free golden/blue-hour planner."""
import datetime as dt
import math
import os
from zoneinfo import ZoneInfo

TZ = ZoneInfo(os.getenv("APP_TZ", "Asia/Kolkata"))


def haversine_km(lat1, lon1, lat2, lon2) -> float:
    r = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def _decl_eqtime(day_of_year: int):
    g = 2 * math.pi / 365 * (day_of_year - 1)
    eqt = 229.18 * (0.000075 + 0.001868 * math.cos(g) - 0.032077 * math.sin(g)
                    - 0.014615 * math.cos(2 * g) - 0.040849 * math.sin(2 * g))
    decl = (0.006918 - 0.399912 * math.cos(g) + 0.070257 * math.sin(g)
            - 0.006758 * math.cos(2 * g) + 0.000907 * math.sin(2 * g)
            - 0.002697 * math.cos(3 * g) + 0.00148 * math.sin(3 * g))
    return decl, eqt


def sun_event(lat: float, lng: float, day: dt.date, altitude_deg: float, rising: bool):
    """Local datetime when the sun crosses `altitude_deg` (None in polar edge cases)."""
    decl, eqt = _decl_eqtime(day.timetuple().tm_yday)
    lat_r = math.radians(lat)
    cos_h = (math.sin(math.radians(altitude_deg)) - math.sin(lat_r) * math.sin(decl)) / (
        math.cos(lat_r) * math.cos(decl))
    if abs(cos_h) > 1:
        return None
    h = math.degrees(math.acos(cos_h))
    noon_utc_min = 720 - 4 * lng - eqt
    minutes = noon_utc_min - 4 * h if rising else noon_utc_min + 4 * h
    base = dt.datetime(day.year, day.month, day.day, tzinfo=dt.timezone.utc)
    return (base + dt.timedelta(minutes=minutes)).astimezone(TZ)


def light_plan(lat: float, lng: float, when: dt.datetime) -> dict:
    """Golden-hour / blue-hour windows for the shoot day plus advice for the booked time."""
    day = when.date()
    ev = lambda alt, rise: sun_event(lat, lng, day, alt, rise)  # noqa: E731
    w = {
        "sunrise": ev(-0.833, True), "sunset": ev(-0.833, False),
        "blue_am": (ev(-6, True), ev(-4, True)),
        "golden_am": (ev(-4, True), ev(6, True)),
        "golden_pm": (ev(6, False), ev(-4, False)),
        "blue_pm": (ev(-4, False), ev(-6, False)),
    }
    if not all([w["sunrise"], w["sunset"], w["golden_am"][0], w["golden_pm"][0]]):
        return {"available": False}
    fmt = lambda x: x.strftime("%H:%M")  # noqa: E731
    out = {"available": True, "date": day.isoformat(), "tz": str(TZ)}
    for k, v in w.items():
        out[k] = fmt(v) if not isinstance(v, tuple) else f"{fmt(v[0])} – {fmt(v[1])}"
    local = when.replace(tzinfo=TZ)
    best, gap = None, None
    for label, (a, b) in (("morning golden hour", w["golden_am"]), ("evening golden hour", w["golden_pm"])):
        if a <= local <= b:
            out["advice"] = f"Booked time falls inside the {label}. Soft, warm light."
            out["advice_level"] = "good"
            return out
        d = min(abs((local - a).total_seconds()), abs((local - b).total_seconds())) / 60
        if gap is None or d < gap:
            best, gap = label, d
    if local < w["sunrise"] or local > w["sunset"]:
        out["advice"] = "Booked time is outside daylight. Plan artificial lighting."
        out["advice_level"] = "warn"
    else:
        out["advice"] = f"Booked time is {int(gap)} min from the nearest {best}. Consider shifting for softer light."
        out["advice_level"] = "info" if gap <= 90 else "warn"
    return out
