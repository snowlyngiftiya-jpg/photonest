const CSRF = document.querySelector('meta[name="csrf"]')?.content || "";
async function api(url, body, method = "POST") {
  const r = await fetch(url, {method, headers: {"Content-Type": "application/json", "X-CSRF-Token": CSRF},
    body: body === undefined ? undefined : JSON.stringify(body)});
  let data = {}; try { data = await r.json(); } catch (e) {}
  if (!r.ok) throw new Error(data.error || r.statusText);
  return data;
}
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
const inr = n => "₹" + Math.round(n || 0).toLocaleString("en-IN");
const PALETTE = ["#e0287d", "#a3188f", "#ff8fb8", "#7b2cbf", "#f4a261", "#2a9d8f", "#5b8def", "#c9184a", "#ffb3d1", "#6d597a"];

// lightbox (images + video)
const lb = document.createElement("div"); lb.className = "lb"; lb.innerHTML = '<button class="x" aria-label="Close">×</button><div></div>';
document.body.appendChild(lb);
lb.addEventListener("click", e => { if (e.target === lb || e.target.classList.contains("x")) closeLb(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeLb(); });
function closeLb() { lb.classList.remove("open"); lb.lastChild.innerHTML = ""; }
function openLb(kind, src, embed) {
  const h = kind === "image" ? `<img src="${src}" alt="">` : embed
    ? `<iframe src="${src}" width="900" height="506" style="max-width:94vw;border:0;border-radius:12px" allowfullscreen></iframe>`
    : `<video src="${src}" controls autoplay></video>`;
  lb.lastChild.innerHTML = h; lb.classList.add("open");
}
document.addEventListener("click", e => {
  const el = e.target.closest("[data-lb]"); if (!el) return;
  openLb(el.dataset.lb, el.dataset.src, el.dataset.embed === "1");
});
document.querySelectorAll(".flash").forEach(f => setTimeout(() => f.style.display = "none", 9000));
