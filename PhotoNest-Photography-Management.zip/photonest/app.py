"""PhotoNest: Photography Management System (Flask + MongoDB).  Run: python app.py"""
import base64
import datetime as dt
import json
import os
import re
import secrets
from functools import wraps

from bson import ObjectId
from dotenv import load_dotenv
from flask import (Flask, Response, abort, flash, jsonify, redirect, render_template, request, session, url_for)
from flask.json.provider import DefaultJSONProvider
from werkzeug.security import check_password_hash, generate_password_hash

load_dotenv()
import analytics  # noqa: E402
import db as dbm  # noqa: E402
import geo  # noqa: E402
import media as mediam  # noqa: E402
import seed as seedmod  # noqa: E402


class Provider(DefaultJSONProvider):
    @staticmethod
    def default(o):
        if isinstance(o, ObjectId):
            return str(o)
        if isinstance(o, (dt.datetime, dt.date)):
            return o.isoformat()
        return DefaultJSONProvider.default(o)


app = Flask(__name__)
app.json = Provider(app)
app.secret_key = os.getenv("SECRET_KEY") or secrets.token_hex(32)
app.config["MAX_CONTENT_LENGTH"] = int(os.getenv("MAX_UPLOAD_BYTES", 80 * 1024 * 1024))
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_HASH = generate_password_hash(os.getenv("ADMIN_PASSWORD", "photonest123"))

store = dbm.connect()
db = store.db
dbm.ensure_indexes(db)
if os.getenv("SEED_DEMO", "1") == "1" and not db.photographers.count_documents({}):
    seedmod.seed(store)

CATEGORIES = ["Wedding", "Portrait", "Event", "Product", "Travel", "Corporate", "Wildlife", "Graduation"]
STATUSES = ["enquiry", "booked", "shot", "editing", "delivered"]
BLOBS = {"data_url": "<base64 omitted>", "thumb": "<thumbnail omitted>"}
LIGHT_PROJ = {"media.data_url": 0, "media.thumb": 0}   # keep pages light: blobs are served by /media routes


# ------------------------------------------------------------------ helpers
def oid(value):
    try:
        return ObjectId(value)
    except Exception:  # noqa: BLE001
        abort(404)


def get_shoot(sid, projection=None):
    d = db.shoots.find_one({"_id": oid(sid)}, projection)
    if not d:
        abort(404)
    return d


def flt(name, default=None):
    try:
        return float(request.values.get(name, default))
    except (TypeError, ValueError):
        return default


def parse_dt(text):
    try:
        return dt.datetime.fromisoformat(text)
    except (TypeError, ValueError):
        return None


def clean(obj):
    """Replace heavy blobs in any document before sending it to the browser."""
    if isinstance(obj, dict):
        return {k: (BLOBS[k] if k in BLOBS else clean(v)) for k, v in obj.items()}
    if isinstance(obj, list):
        return [clean(v) for v in obj]
    return obj


def slugify(text):
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-") + "-" + secrets.token_hex(2)


def find_media(sid, mid):
    d = db.shoots.find_one({"_id": oid(sid)}, {"media": {"$elemMatch": {"_id": mid}}})
    if not d or not d.get("media"):
        abort(404)
    return d["media"][0]


# ------------------------------------------------------------------ auth + csrf
PUBLIC = {"login", "static", "health", "proof_page", "proof_media", "proof_pick", "proof_comment"}


@app.before_request
def guard():
    session.setdefault("csrf", secrets.token_hex(16))
    ep = request.endpoint or ""
    if request.method in ("POST", "PUT", "PATCH", "DELETE") and not ep.startswith("proof_"):
        sent = request.form.get("csrf") or request.headers.get("X-CSRF-Token")
        if not sent or not secrets.compare_digest(sent, session["csrf"]):
            abort(400, "CSRF token missing or invalid")
    if ep not in PUBLIC and not session.get("user"):
        return redirect(url_for("login", next=request.path))


@app.context_processor
def inject():
    return {"store": store, "csrf": session.get("csrf", ""), "CATEGORIES": CATEGORIES, "STATUSES": STATUSES,
            "now": dt.datetime.utcnow()}


@app.template_filter("inr")
def inr(v):
    return "₹{:,.0f}".format(v or 0)


@app.template_filter("dmy")
def dmy(v, fmt="%d %b %Y, %H:%M"):
    return v.strftime(fmt) if isinstance(v, dt.datetime) else (v or "")


@app.template_filter("mb")
def mb(v):
    return f"{(v or 0) / 1024 / 1024:.2f} MB"


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.form.get("username") == ADMIN_USER and check_password_hash(ADMIN_HASH, request.form.get("password", "")):
            session["user"] = ADMIN_USER
            nxt = request.args.get("next", "")
            return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.get("/api/health")
def health():
    return jsonify(status="ok", mode=store.mode, fallback_reason=store.error)


# ------------------------------------------------------------------ dashboard + analytics
@app.get("/")
def dashboard():
    return render_template("dashboard.html")


@app.get("/api/analytics")
def api_analytics():
    return jsonify(analytics.run_all(db))


# ------------------------------------------------------------------ shoots
@app.get("/shoots")
def shoots():
    q, status, cat = request.args.get("q", "").strip(), request.args.get("status", ""), request.args.get("category", "")
    filt = {}
    if q:
        rx = {"$regex": re.escape(q), "$options": "i"}
        filt["$or"] = [{"title": rx}, {"client.name": rx}, {"venue.city": rx}, {"photographer.name": rx}]
    if status:
        filt["status"] = status
    if cat:
        filt["category"] = cat
    rows = list(db.shoots.find(filt, {"media.data_url": 0, "media.thumb": 0, "proof": 0}).sort("shoot_date", -1))
    return render_template("shoots.html", rows=rows, q=q, status=status, cat=cat)


@app.route("/shoots/new", methods=["GET", "POST"])
def shoot_new():
    people = {"photographers": list(db.photographers.find()), "clients": list(db.clients.find()),
              "equipment": list(db.equipment.find())}
    if request.method == "POST":
        f = request.form
        when, lat, lng = parse_dt(f.get("shoot_date")), flt("lat"), flt("lng")
        ph, cl = db.photographers.find_one({"_id": oid(f.get("photographer"))}), db.clients.find_one({"_id": oid(f.get("client"))})
        if not (f.get("title", "").strip() and when and ph and cl and f.get("category") in CATEGORIES):
            flash("Title, date, category, photographer and client are required.", "error")
            return render_template("shoot_new.html", **people, form=f), 400
        gear = list(db.equipment.find({"_id": {"$in": [oid(x) for x in f.getlist("equipment")]}}))
        eq = [{"id": str(g["_id"]), "name": g["name"], "type": g["type"]} for g in gear]
        clashes = analytics.conflicts(db, when, [e["id"] for e in eq], str(ph["_id"]))
        price, adv = max(flt("price", 0) or 0, 0), max(flt("advance", 0) or 0, 0)
        doc = {
            "slug": slugify(f["title"]), "title": f["title"].strip()[:120], "category": f["category"], "status": "booked",
            "shoot_date": when, "duration_hours": flt("duration", 2) or 2,
            "photographer": {"id": str(ph["_id"]), "name": ph["name"], "specialty": ph.get("specialty", "")},
            "client": {"id": str(cl["_id"]), "name": cl["name"], "email": cl.get("email", ""), "phone": cl.get("phone", "")},
            "venue": {"name": f.get("venue", "")[:120], "city": f.get("city", "")[:60], "address": f.get("address", "")[:200]},
            "package": {"name": f.get("package", "Standard")[:80], "price": price, "currency": "INR"},
            "equipment": eq, "media": [], "created_at": dt.datetime.utcnow(),
            "shot_list": [{"_id": secrets.token_hex(4), "text": t.strip()[:120], "done": False}
                          for t in f.get("shot_list", "").splitlines() if t.strip()][:30],
            "payments": [{"_id": secrets.token_hex(4), "label": "Advance", "amount": min(adv, price), "method": "", "status": "pending",
                          "reference": "", "paid_at": None},
                         {"_id": secrets.token_hex(4), "label": "Balance", "amount": price - min(adv, price), "method": "",
                          "status": "pending", "reference": "", "paid_at": None}],
            "proof": {"token": secrets.token_urlsafe(10), "enabled": True, "selections": [], "comments": []},
        }
        if lat is not None and lng is not None and -90 <= lat <= 90 and -180 <= lng <= 180:
            doc["location"] = {"type": "Point", "coordinates": [lng, lat]}
        res = db.shoots.insert_one(doc)
        for c in clashes:
            flash(f"Heads-up: '{c['title']}' is the same day and also uses {', '.join(c['clash'])}.", "warn")
        flash("Shoot created.", "ok")
        return redirect(url_for("shoot_detail", sid=res.inserted_id))
    return render_template("shoot_new.html", **people, form={})


@app.get("/shoots/<sid>")
def shoot_detail(sid):
    s = get_shoot(sid, LIGHT_PROJ)
    plan = None
    if s.get("location"):
        lng, lat = s["location"]["coordinates"]
        plan = geo.light_plan(lat, lng, s["shoot_date"])
    dups = mediam.find_duplicates(s.get("media", []))
    dup_ids = {x for d in dups for x in (d["a"], d["b"])}
    inline_used = mediam.inline_bytes_used(s)
    paid = sum(p["amount"] for p in s["payments"] if p["status"] == "paid")
    cameras = [e["name"] for e in db.equipment.find({"type": "camera"}, {"name": 1})]
    return render_template("shoot_detail.html", s=s, plan=plan, dups=dups, dup_ids=dup_ids, inline_used=inline_used,
                           budget=mediam.INLINE_DOC_BUDGET, paid=paid, cameras=cameras)


@app.get("/api/shoots/<sid>/raw")
def shoot_raw(sid):
    """The embedded document exactly as stored (binary blobs elided) for demonstrating the schema."""
    return jsonify(clean(get_shoot(sid)))


@app.post("/shoots/<sid>/status")
def shoot_status(sid):
    st = request.form.get("status")
    if st in STATUSES:
        db.shoots.update_one({"_id": oid(sid)}, {"$set": {"status": st}})
    return redirect(url_for("shoot_detail", sid=sid))


@app.post("/shoots/<sid>/delete")
def shoot_delete(sid):
    s = get_shoot(sid)
    for m in s.get("media", []):
        if m.get("gridfs_id"):
            store.fs.delete(m["gridfs_id"])
    db.shoots.delete_one({"_id": s["_id"]})
    flash("Shoot deleted.", "ok")
    return redirect(url_for("shoots"))


@app.post("/api/shoots/<sid>/location")
def shoot_location(sid):
    j = request.get_json(silent=True) or {}
    try:
        lat, lng = float(j["lat"]), float(j["lng"])
        assert -90 <= lat <= 90 and -180 <= lng <= 180
    except Exception:  # noqa: BLE001
        return jsonify(error="Invalid coordinates"), 400
    db.shoots.update_one({"_id": oid(sid)}, {"$set": {"location": {"type": "Point", "coordinates": [lng, lat]}}})
    s = get_shoot(sid, {"shoot_date": 1})
    return jsonify(ok=True, plan=geo.light_plan(lat, lng, s["shoot_date"]))


# ---- embedded sub-documents: shot list, payments, proof settings
@app.post("/shoots/<sid>/shots")
def shot_add(sid):
    text = request.form.get("text", "").strip()[:120]
    if text:
        db.shoots.update_one({"_id": oid(sid)}, {"$push": {"shot_list": {"_id": secrets.token_hex(4), "text": text, "done": False}}})
    return redirect(url_for("shoot_detail", sid=sid) + "#shots")


@app.post("/api/shoots/<sid>/shots/<item>")
def shot_toggle(sid, item):
    done = bool((request.get_json(silent=True) or {}).get("done"))
    db.shoots.update_one({"_id": oid(sid), "shot_list._id": item}, {"$set": {"shot_list.$.done": done}})
    return jsonify(ok=True)


@app.post("/shoots/<sid>/payments")
def payment_add(sid):
    amt = flt("amount", 0) or 0
    if amt > 0:
        db.shoots.update_one({"_id": oid(sid)}, {"$push": {"payments": {
            "_id": secrets.token_hex(4), "label": request.form.get("label", "Payment")[:60], "amount": amt, "method": "",
            "status": "pending", "reference": "", "paid_at": None}}})
    return redirect(url_for("shoot_detail", sid=sid) + "#payments")


@app.post("/shoots/<sid>/payments/<pid>/paid")
def payment_paid(sid, pid):
    db.shoots.update_one({"_id": oid(sid), "payments._id": pid}, {"$set": {
        "payments.$.status": "paid", "payments.$.paid_at": dt.datetime.utcnow(),
        "payments.$.method": request.form.get("method", "UPI")[:30], "payments.$.reference": request.form.get("reference", "")[:60]}})
    flash("Payment recorded (record keeping only, no real transaction).", "ok")
    return redirect(url_for("shoot_detail", sid=sid) + "#payments")


@app.post("/shoots/<sid>/proof")
def proof_settings(sid):
    action = request.form.get("action")
    if action == "toggle":
        s = get_shoot(sid, {"proof.enabled": 1})
        db.shoots.update_one({"_id": s["_id"]}, {"$set": {"proof.enabled": not s["proof"]["enabled"]}})
    elif action == "rotate":
        db.shoots.update_one({"_id": oid(sid)}, {"$set": {"proof.token": secrets.token_urlsafe(10)}})
    return redirect(url_for("shoot_detail", sid=sid) + "#proof")


# ------------------------------------------------------------------ media (embedded docs + GridFS)
@app.post("/shoots/<sid>/media")
def media_upload(sid):
    s = get_shoot(sid, LIGHT_PROJ)
    caption, tags = request.form.get("caption", ""), mediam.parse_tags(request.form.get("tags", ""))
    cam = request.form.get("camera") or None
    loc = None
    if flt("lat") is not None and flt("lng") is not None:
        loc = {"type": "Point", "coordinates": [flt("lng"), flt("lat")]}
    added = 0
    for f in request.files.getlist("files"):
        if not f.filename:
            continue
        try:
            m = mediam.ingest(store, s, f.read(), f.filename, f.mimetype, caption, tags, cam, loc)
        except mediam.MediaError as exc:
            flash(str(exc), "error")
            continue
        existing = [x for x in s.get("media", []) if x.get("phash") and m.get("phash")
                    and mediam.hamming(x["phash"], m["phash"]) <= 5]
        db.shoots.update_one({"_id": s["_id"]}, {"$push": {"media": m}})
        s.setdefault("media", []).append({k: v for k, v in m.items() if k not in BLOBS})
        added += 1
        tier = "embedded in the document" if m["storage"] == "inline" else "stored in GridFS"
        flash(f"{m['filename']} added ({tier}).", "ok")
        if existing:
            flash(f"{m['filename']} looks like a duplicate of {existing[0]['filename']}.", "warn")
    if not added and not request.files.getlist("files"):
        flash("Choose at least one file.", "error")
    return redirect(url_for("shoot_detail", sid=sid) + "#gallery")


@app.post("/shoots/<sid>/media/link")
def media_link(sid):
    try:
        m = mediam.external_link(request.form.get("url", "").strip(), request.form.get("caption", ""),
                                 mediam.parse_tags(request.form.get("tags", "")))
        db.shoots.update_one({"_id": oid(sid)}, {"$push": {"media": m}})
        flash("Link embedded.", "ok")
    except mediam.MediaError as exc:
        flash(str(exc), "error")
    return redirect(url_for("shoot_detail", sid=sid) + "#gallery")


@app.post("/api/shoots/<sid>/media/<mid>")
def media_patch(sid, mid):
    j = request.get_json(silent=True) or {}
    sets = {}
    if "rating" in j and isinstance(j["rating"], int) and 0 <= j["rating"] <= 5:
        sets["media.$.rating"] = j["rating"]
    if "favorite" in j:
        sets["media.$.favorite"] = bool(j["favorite"])
    if "caption" in j:
        sets["media.$.caption"] = str(j["caption"])[:200]
    if "tags" in j:
        sets["media.$.tags"] = mediam.parse_tags(",".join(map(str, j["tags"])) if isinstance(j["tags"], list) else str(j["tags"]))
    if not sets:
        return jsonify(error="nothing to update"), 400
    r = db.shoots.update_one({"_id": oid(sid), "media._id": mid}, {"$set": sets})
    return jsonify(ok=bool(r.matched_count))


@app.post("/api/shoots/<sid>/media/<mid>/delete")
def media_delete(sid, mid):
    m = find_media(sid, mid)
    if m.get("gridfs_id"):
        store.fs.delete(m["gridfs_id"])
    db.shoots.update_one({"_id": oid(sid)}, {"$pull": {"media": {"_id": mid}}})
    db.shoots.update_one({"_id": oid(sid)}, {"$pull": {"proof.selections": mid}})
    return jsonify(ok=True)


def serve_media(m, variant):
    if variant == "thumb" and m.get("thumb"):
        if m["thumb"].startswith("http"):
            return redirect(m["thumb"])
        raw, mime = mediam.decode_data_url(m["thumb"])
        return Response(raw, mimetype=mime, headers={"Cache-Control": "private, max-age=86400"})
    if m.get("storage") == "external":
        return redirect(m["url"])
    if m.get("storage") == "inline":
        raw, mime = mediam.decode_data_url(m["data_url"])
        return Response(raw, mimetype=mime, headers={"Cache-Control": "private, max-age=86400"})
    grid = store.fs.get(m["gridfs_id"])
    size, mime = grid.length, m.get("mime") or "application/octet-stream"
    rng = request.headers.get("Range")
    start, end, status = 0, size - 1, 200
    if rng and (mt := re.match(r"bytes=(\d*)-(\d*)", rng)):
        if mt.group(1):
            start = int(mt.group(1))
            end = int(mt.group(2)) if mt.group(2) else size - 1
        elif mt.group(2):
            start = max(size - int(mt.group(2)), 0)
        end = min(end, size - 1)
        if start > end:
            return Response(status=416, headers={"Content-Range": f"bytes */{size}"})
        status = 206
    grid.seek(start)
    body = grid.read(end - start + 1)
    h = {"Accept-Ranges": "bytes", "Cache-Control": "private, max-age=3600", "Content-Length": str(len(body))}
    if status == 206:
        h["Content-Range"] = f"bytes {start}-{end}/{size}"
    return Response(body, status=status, mimetype=mime, headers=h)


@app.get("/media/<sid>/<mid>")
@app.get("/media/<sid>/<mid>/<variant>")
def media_file(sid, mid, variant="full"):
    return serve_media(find_media(sid, mid), variant)


# ------------------------------------------------------------------ gallery (cross-shoot search over embedded media)
@app.get("/gallery")
def gallery():
    a = request.args
    match = {}
    if a.get("tag"):
        match["media.tags"] = a["tag"].lower().lstrip("#")
    if a.get("camera"):
        match["media.exif.camera"] = a["camera"]
    if a.get("min_rating", "").isdigit():
        match["media.rating"] = {"$gte": int(a["min_rating"])}
    if a.get("favorite") == "1":
        match["media.favorite"] = True
    if a.get("kind") in ("image", "video"):
        match["media.kind"] = a["kind"]
    if a.get("q"):
        match["media.caption"] = {"$regex": re.escape(a["q"]), "$options": "i"}
    pipe = [{"$unwind": "$media"}, {"$match": match}, {"$sort": {"media.uploaded_at": -1}}, {"$limit": 400},
            {"$project": {"sid": "$_id", "shoot": "$title", "m": {
                "_id": "$media._id", "kind": "$media.kind", "caption": "$media.caption", "rating": "$media.rating",
                "favorite": "$media.favorite", "tags": "$media.tags", "exif": "$media.exif", "palette": "$media.palette",
                "storage": "$media.storage", "size": "$media.size"}}}]
    rows = list(db.shoots.aggregate(pipe))
    color = a.get("color", "")
    if re.fullmatch(r"#[0-9a-fA-F]{6}", color):
        rows = [r for r in rows if r["m"].get("palette")]
        for r in rows:
            r["dist"] = min(mediam.color_distance(color.lower(), p) for p in r["m"]["palette"])
        rows = sorted((r for r in rows if r["dist"] < 120), key=lambda r: r["dist"])
    all_tags = sorted({t for s in db.shoots.find({}, {"media.tags": 1}) for m in s.get("media", []) for t in m.get("tags", [])})
    cameras = db.shoots.distinct("media.exif.camera")
    return render_template("gallery.html", rows=rows[:120], total=len(rows), a=a, all_tags=all_tags, cameras=sorted(cameras))


# ------------------------------------------------------------------ map / geo
@app.get("/map")
def map_page():
    return render_template("map.html")


@app.get("/api/geo")
def api_geo():
    rows = db.shoots.find({"location": {"$exists": True}}, {"title": 1, "category": 1, "status": 1, "venue": 1, "location": 1, "shoot_date": 1})
    return jsonify([{"id": r["_id"], "title": r["title"], "category": r["category"], "status": r["status"],
                     "venue": r["venue"]["name"], "city": r["venue"]["city"], "date": r["shoot_date"],
                     "lat": r["location"]["coordinates"][1], "lng": r["location"]["coordinates"][0]} for r in rows])


@app.get("/api/nearby")
def api_nearby():
    lat, lng, km = flt("lat"), flt("lng"), flt("km", 50)
    if lat is None or lng is None or not (-90 <= lat <= 90 and -180 <= lng <= 180):
        return jsonify(error="lat/lng required"), 400
    km = min(max(km or 50, 1), 5000)
    return jsonify(analytics.nearby(store, lat, lng, km))


# ------------------------------------------------------------------ explorer (read-only query lab)
ALLOWED_COLLECTIONS = {"shoots", "clients", "photographers", "equipment"}
ALLOWED_STAGES = {"$match", "$group", "$project", "$sort", "$limit", "$skip", "$unwind", "$count", "$addFields", "$set",
                  "$unset", "$bucket", "$bucketAuto", "$sortByCount", "$replaceRoot", "$facet"}
BLOCKED_OPS = {"$where", "$function", "$accumulator", "$out", "$merge", "$lookup", "$graphLookup", "$unionWith"}


def scan(obj):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in BLOCKED_OPS:
                raise ValueError(f"operator {k} is not allowed in the read-only explorer")
            scan(v)
    elif isinstance(obj, list):
        for v in obj:
            scan(v)


def revive(obj):
    """Allow {"$date": "2026-01-01"} in explorer JSON."""
    if isinstance(obj, dict):
        if set(obj) == {"$date"}:
            return dt.datetime.fromisoformat(str(obj["$date"]).replace("Z", ""))
        return {k: revive(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [revive(v) for v in obj]
    return obj


def explorer_error(exc):
    return jsonify(error=f"{type(exc).__name__}: {str(exc)[:300]}"), 400


@app.get("/explorer")
def explorer():
    return render_template("explorer.html", catalog=analytics.CATALOG)


@app.post("/api/explorer/aggregate")
def explorer_aggregate():
    j = request.get_json(silent=True) or {}
    try:
        coll = j.get("collection")
        if coll not in ALLOWED_COLLECTIONS:
            raise ValueError("unknown collection")
        pipe = revive(j["pipeline"] if isinstance(j.get("pipeline"), list) else json.loads(j.get("pipeline", "[]")))
        if not isinstance(pipe, list) or len(pipe) > 12:
            raise ValueError("pipeline must be an array of at most 12 stages")
        for st in pipe:
            if not isinstance(st, dict) or len(st) != 1 or next(iter(st)) not in ALLOWED_STAGES:
                raise ValueError(f"stage not allowed: {json.dumps(st)[:60]}")
        scan(pipe)
        if not any("$limit" in st for st in pipe):
            pipe.append({"$limit": 100})
        t0 = dt.datetime.now()
        rows = clean(list(db[coll].aggregate(pipe)))
        ms = round((dt.datetime.now() - t0).total_seconds() * 1000, 1)
        return jsonify(rows=rows, count=len(rows), ms=ms, pipeline=pipe)
    except Exception as exc:  # noqa: BLE001
        return explorer_error(exc)


@app.post("/api/explorer/find")
def explorer_find():
    j = request.get_json(silent=True) or {}
    try:
        coll = j.get("collection")
        if coll not in ALLOWED_COLLECTIONS:
            raise ValueError("unknown collection")
        filt = revive(json.loads(j.get("filter") or "{}"))
        sort = json.loads(j.get("sort") or "null")
        scan(filt)
        cur = db[coll].find(filt, {"media.data_url": 0, "media.thumb": 0, "proof": 0}).limit(min(int(j.get("limit", 20)), 100))
        if sort:
            cur = cur.sort(list(sort.items()))
        rows = clean(list(cur))
        explain = None
        if store.mode == "mongodb":
            try:
                plan = db[coll].find(filt).explain()["queryPlanner"]["winningPlan"]
                explain = json.loads(json.dumps(plan, default=str))
            except Exception:  # noqa: BLE001
                pass
        return jsonify(rows=rows, count=len(rows), explain=explain)
    except Exception as exc:  # noqa: BLE001
        return explorer_error(exc)


# ------------------------------------------------------------------ people + equipment
@app.get("/people")
def people():
    return render_template("people.html", photographers=list(db.photographers.find()), clients=list(db.clients.find()))


@app.post("/people/<kind>")
def people_add(kind):
    f = request.form
    if kind not in ("photographers", "clients") or not f.get("name", "").strip():
        abort(400)
    doc = {"name": f["name"].strip()[:80], "email": f.get("email", "")[:120], "phone": f.get("phone", "")[:20],
           "created_at": dt.datetime.utcnow()}
    doc["specialty" if kind == "photographers" else "organisation"] = f.get("extra", "")[:100]
    db[kind].insert_one(doc)
    return redirect(url_for("people"))


@app.get("/equipment")
def equipment():
    return render_template("equipment.html", items=list(db.equipment.find().sort("type", 1)), use=analytics.equipment_utilisation(db))


@app.post("/equipment")
def equipment_add():
    f = request.form
    if f.get("name", "").strip():
        db.equipment.insert_one({"name": f["name"].strip()[:80], "type": f.get("type", "other"), "serial": f.get("serial", "")[:40],
                                 "status": "available", "maintenance_log": []})
    return redirect(url_for("equipment"))


@app.post("/equipment/<eid>/status")
def equipment_status(eid):
    if request.form.get("status") in ("available", "maintenance", "retired"):
        db.equipment.update_one({"_id": oid(eid)}, {"$set": {"status": request.form["status"]}})
    return redirect(url_for("equipment"))


@app.post("/equipment/<eid>/maintenance")
def equipment_maint(eid):
    note = request.form.get("note", "").strip()[:200]
    if note:
        db.equipment.update_one({"_id": oid(eid)}, {"$push": {"maintenance_log": {
            "_id": secrets.token_hex(4), "date": dt.datetime.utcnow(), "note": note, "cost": flt("cost", 0) or 0}}})
    return redirect(url_for("equipment"))


# ------------------------------------------------------------------ public client proofing
def proof_shoot(token):
    s = db.shoots.find_one({"proof.token": token, "proof.enabled": True}, {**LIGHT_PROJ, "payments": 0, "equipment": 0})
    if not s:
        abort(404)
    return s


@app.get("/proof/<token>")
def proof_page(token):
    s = proof_shoot(token)
    imgs = [m for m in s.get("media", []) if m.get("kind") == "image"]
    return render_template("proof.html", s=s, imgs=imgs, picks=set(s["proof"]["selections"]))


@app.get("/proof/<token>/media/<mid>")
@app.get("/proof/<token>/media/<mid>/<variant>")
def proof_media(token, mid, variant="full"):
    s = proof_shoot(token)
    m = next((x for x in db.shoots.find_one({"_id": s["_id"]}, {"media": {"$elemMatch": {"_id": mid, "kind": "image"}}}).get("media", [])), None)
    if not m:
        abort(404)
    return serve_media(m, variant)


@app.post("/proof/<token>/pick")
def proof_pick(token):
    s = proof_shoot(token)
    j = request.get_json(silent=True) or {}
    mid = str(j.get("id", ""))
    if not any(m["_id"] == mid for m in s.get("media", [])):
        return jsonify(error="unknown photo"), 400
    op = "$addToSet" if j.get("picked") else "$pull"
    db.shoots.update_one({"_id": s["_id"]}, {op: {"proof.selections": mid}})
    return jsonify(ok=True)


@app.post("/proof/<token>/comment")
def proof_comment(token):
    s = proof_shoot(token)
    text, author = request.form.get("text", "").strip()[:500], request.form.get("author", "").strip()[:60] or "Client"
    if text:
        db.shoots.update_one({"_id": s["_id"]}, {"$push": {"proof.comments": {"author": author, "text": text, "at": dt.datetime.utcnow()}}})
        flash("Thanks, your feedback was sent to the photographer.", "ok")
    return redirect(url_for("proof_page", token=token))


@app.errorhandler(404)
def nf(_):
    return render_template("error.html", code=404, msg="That page was not found."), 404


@app.errorhandler(400)
def bad(e):
    return render_template("error.html", code=400, msg=getattr(e, "description", "Bad request")), 400


@app.errorhandler(413)
def big(_):
    return render_template("error.html", code=413, msg="Upload is too large."), 413


if __name__ == "__main__":
    app.run(host=os.getenv("HOST", "127.0.0.1"), port=int(os.getenv("PORT", 5000)), debug=os.getenv("FLASK_DEBUG") == "1")
