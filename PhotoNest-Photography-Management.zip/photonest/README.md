# PhotoNest: Photography Management System (Flask + MongoDB)

CO5 micro project. Manage photo shoots, store images / videos / locations as **embedded MongoDB documents**,
fetch them back, and explore the data through an **analytics dashboard and a Mongo query explorer**.

## Run it

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # set MONGODB_URI (local or Atlas)
python app.py                                          # http://127.0.0.1:5000
```

Login: `admin` / `photonest123` (change in `.env`). Demo data seeds automatically on first run
(`python seed.py --reset` to reload). If no MongoDB server is reachable the app falls back to an in-memory
demo database and shows a banner, so it never fails to start. Run the tests with `python -m pytest -q`.
Charts, maps and fonts load from CDNs, so the browser needs internet access.

## Requirement checklist

| Requirement | Where |
|---|---|
| Flask + MongoDB | `app.py`, `db.py` (pymongo, GridFS, indexes) |
| Embedded documents for images / videos / location | one `shoots` document embeds `media[]`, `location` (GeoJSON Point), `venue`, `payments[]`, `shot_list[]`, `equipment[]`, `proof{}` |
| Store and fetch media | `media.py` (ingest), `/media/<shoot>/<media>` (serve, with HTTP Range for video) |
| Locations | GeoJSON + `2dsphere` index, map pins, click-to-pin, live GPS (`watchPosition`), `$geoNear` nearby search |
| Dashboard analytics exploring Mongo queries | `/` (13 aggregation charts, each with its pipeline) and `/explorer` |

## Document design (`shoots` collection)

```
{ title, category, status, shoot_date, slug,
  photographer: {id, name, specialty}, client: {id, name, email, phone},   # embedded snapshots
  venue: {name, city, address}, location: {type:"Point", coordinates:[lng,lat]},
  package: {name, price}, equipment: [{id, name, type}],
  shot_list: [{_id, text, done}], payments: [{_id, label, amount, status, paid_at, ...}],
  media: [{ _id, kind:"image|video", storage:"inline|gridfs|external",
            data_url | gridfs_id | url, thumb, exif:{camera,lens,iso,aperture,shutter,...},
            palette:[...], phash, tags:[...], rating, favorite, location:{Point} }],
  proof: {token, enabled, selections:[media_id], comments:[{author,text,at}]} }
```
Other collections: `photographers`, `clients`, `equipment` (embeds `maintenance_log[]`).
**Storage tiering:** images up to 2 MB are embedded as base64 while the shoot stays under a 6 MB budget; bigger images
and all videos go to GridFS; the descriptor always stays embedded. YouTube / direct URLs are embedded as links.

## Innovative features

1. **Client proofing links**: a public tokenised page where clients heart photos and comment; picks are written back into `proof{}` with `$addToSet` / `$push`.
2. **Auto EXIF extraction** at upload (camera, lens, ISO, aperture, shutter, GPS), feeding the camera and ISO charts.
3. **Dominant colour palette** per photo and **search by similar colour**.
4. **Duplicate detection** with a perceptual (average) hash and Hamming distance.
5. **Golden-hour / blue-hour planner** computed from the shoot's pin and date (no API) with advice for the booked time.
6. **Double-booking detection** for photographer and gear on the same day.
7. **Smart storage tiering** with a live budget meter (inline vs GridFS).
8. **Cross-shoot gallery search** using `$unwind` over embedded media (tag, camera, rating, favourite, colour).
9. **Culling workflow**: star ratings, favourites, shot-list checklist, pipeline status (enquiry to delivered).
10. **Payments ledger** (record keeping only), outstanding dues analytics.
11. **Raw document inspector** on every shoot to show the stored embedded document.
12. **Read-only Mongo Explorer**: edit pipelines or `find` filters, see timing and (on real MongoDB) the `explain` plan; write stages and `$where/$function/$out/$merge/$lookup` are blocked.

## MongoDB concepts demonstrated

`$group`, `$sum`, `$avg`, `$max`, `$sort`, `$limit`, `$match`, `$unwind` (single and double), `$size`, `$bucket`, `$dateToString`,
`$dayOfWeek`, `$cond`, `$ifNull`, `$project`, `$geoNear`, `$elemMatch`, positional `$` updates, `$push`, `$pull`, `$addToSet`,
compound / multikey / unique / 2dsphere indexes, GridFS.

## Security notes

Session login, CSRF token on every write, upload type and size validation (images are decoded with Pillow), parameterised
queries only, explorer allow-list, proof links are unguessable tokens that can be disabled or rotated. Demo photos are
synthetic gradients labelled "PhotoNest demo frame"; use `SEED_DEMO=0` on a fresh database to start empty.

## Files

`app.py` routes · `db.py` connection + indexes · `media.py` upload pipeline · `analytics.py` pipelines · `geo.py` light planner ·
`seed.py` demo data · `templates/`, `static/` UI · `tests/test_smoke.py` end-to-end tests.
