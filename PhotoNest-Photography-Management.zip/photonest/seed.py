"""Demo data. Generates synthetic gradient 'photos' with real EXIF (so the upload pipeline,
EXIF analytics, palettes and duplicate detection are exercised) and loads people, gear and shoots.
Every seeded document carries demo=True. Run:  python seed.py [--reset]
"""
import datetime as dt
import io
import random
import secrets
import sys

from PIL import Image, ImageDraw, ImageFilter, ImageOps

import media as mediam

R = random.Random(42)
THEMES = {
    "sunset": ((40, 10, 60), (255, 140, 90)), "bluehour": ((10, 20, 70), (120, 150, 230)),
    "forest": ((10, 50, 30), (170, 220, 120)), "studio": ((60, 60, 70), (240, 230, 240)),
    "rose": ((120, 20, 80), (255, 190, 215)), "ocean": ((0, 60, 100), (150, 230, 235)),
}
GEAR = [("Canon EOS R6", "RF 24-70mm F2.8 L IS USM"), ("Sony ILCE-7M3", "FE 85mm F1.4 GM"),
        ("NIKON Z 6_2", "NIKKOR Z 70-200mm f/2.8"), ("FUJIFILM X-T4", "XF 16-55mm F2.8")]
TAGS = {
    "Wedding": ["bride", "ceremony", "candid", "couple", "decor"], "Portrait": ["portrait", "studio", "headshot", "fashion"],
    "Event": ["stage", "crowd", "candid", "speaker"], "Product": ["product", "flatlay", "studio", "macro"],
    "Travel": ["landscape", "street", "sunset", "heritage"], "Corporate": ["team", "headshot", "office"],
    "Wildlife": ["wildlife", "birds", "landscape", "macro"], "Graduation": ["convocation", "group", "candid"],
}


def fake_photo(theme: str, idx: int, camera: str, lens: str, iso: int, ap: float, sh: int, fl: int, taken: dt.datetime,
               gps=None) -> bytes:
    c1, c2 = THEMES[theme]
    w, h = 960, 640
    grad = Image.linear_gradient("L").resize((w, h)).rotate(R.choice([0, 90, 180, 270]) if idx % 2 else 0)
    img = ImageOps.colorize(grad.resize((w, h)), c1, c2).convert("RGB")
    d = ImageDraw.Draw(img, "RGBA")
    for _ in range(6):
        x, y, r = R.randint(0, w), R.randint(0, h), R.randint(40, 200)
        d.ellipse([x - r, y - r, x + r, y + r], fill=(*[R.randint(150, 255) for _ in range(3)], R.randint(30, 90)))
    img = img.filter(ImageFilter.GaussianBlur(6))
    d = ImageDraw.Draw(img)
    d.text((18, h - 28), f"PhotoNest demo frame #{idx}  |  {theme}", fill=(255, 255, 255))
    ex = Image.Exif()
    ex[271], ex[272] = camera.split(" ")[0], camera
    sub = ex.get_ifd(0x8769)
    sub[34855], sub[33437], sub[33434], sub[37386] = iso, ap, 1 / sh, fl
    sub[42036], sub[36867] = lens, taken.strftime("%Y:%m:%d %H:%M:%S")
    if gps:
        g = ex.get_ifd(0x8825)
        lat, lng = gps

        def dms(v):
            v = abs(v)
            return (int(v), int((v % 1) * 60), round(((v * 60) % 1) * 60, 2))
        g[1], g[2], g[3], g[4] = "N" if lat >= 0 else "S", dms(lat), "E" if lng >= 0 else "W", dms(lng)
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=82, exif=ex)
    return buf.getvalue()


PHOTOGRAPHERS = [
    ("Ananya Rao", "ananya@photonest.demo", "Weddings & portraits", "9876500011"),
    ("Karthik Raja", "karthik@photonest.demo", "Events & corporate", "9876500012"),
    ("Meera Nair", "meera@photonest.demo", "Travel & wildlife", "9876500013"),
    ("Dev Anand", "dev@photonest.demo", "Product & studio", "9876500014"),
]
CLIENTS = [
    ("Priya & Arjun", "priya@example.com", "9000000001", ""), ("NEC Cultural Club", "culture@example.com", "9000000002", "National Engineering College"),
    ("Lotus Jewellers", "hello@lotus.example", "9000000003", "Lotus Jewellers"), ("Sneha Iyer", "sneha@example.com", "9000000004", ""),
    ("TechSpark Pvt Ltd", "hr@techspark.example", "9000000005", "TechSpark"), ("Rahul Menon", "rahul@example.com", "9000000006", ""),
    ("IT Dept Alumni", "alumni@example.com", "9000000007", "NEC IT Department"),
]
EQUIPMENT = [
    ("Canon EOS R6", "camera", "CN-R6-0192", "available"), ("Sony A7 III", "camera", "SN-A73-5521", "available"),
    ("Nikon Z6 II", "camera", "NK-Z62-8830", "maintenance"), ("Fujifilm X-T4", "camera", "FJ-XT4-1204", "available"),
    ("RF 24-70mm f/2.8", "lens", "CN-L2470-77", "available"), ("FE 85mm f/1.4 GM", "lens", "SN-L85-312", "available"),
    ("DJI Air 3", "drone", "DJ-A3-4410", "available"), ("Godox AD600 Pro", "light", "GD-AD600-09", "available"),
    ("Manfrotto Tripod 055", "support", "MF-055-120", "available"),
]
# title, category, days_from_now, hour, venue, city, lat, lng, photographer idx, client idx, package, price, status, gear idxs
SHOOTS = [
    ("Priya & Arjun Wedding", "Wedding", -150, 7, "Arulmigu Subramaniaswamy Temple", "Thoothukudi", 8.7642, 78.1348, 0, 0, "Premium Wedding", 85000, "delivered", [0, 4, 7]),
    ("Lotus Jewellers Catalogue", "Product", -120, 11, "Lotus Showroom", "Tirunelveli", 8.7139, 77.7567, 3, 2, "Catalogue 60 SKUs", 32000, "delivered", [1, 5, 7]),
    ("Cultural Fest Day 1", "Event", -95, 17, "NEC Open Air Theatre", "Kovilpatti", 9.1726, 77.8683, 1, 1, "Event Coverage", 18000, "delivered", [0, 3]),
    ("Meenakshi Temple Heritage Walk", "Travel", -70, 6, "Meenakshi Amman Temple", "Madurai", 9.9195, 78.1193, 2, 3, "Travel Story", 22000, "delivered", [1, 6]),
    ("Sneha Graduation Portraits", "Graduation", -55, 16, "NEC Main Block", "Kovilpatti", 9.1700, 77.8700, 0, 3, "Mini Portrait", 6500, "delivered", [3, 4]),
    ("TechSpark Team Headshots", "Corporate", -40, 10, "TechSpark HQ", "Chennai", 13.0827, 80.2707, 1, 4, "Corporate 40 Headshots", 28000, "editing", [0, 7]),
    ("Courtallam Monsoon Series", "Wildlife", -28, 6, "Main Falls", "Courtallam", 8.9300, 77.2700, 2, 5, "Nature Series", 15000, "editing", [1, 6]),
    ("Kanyakumari Sunrise Portraits", "Portrait", -14, 5, "Vivekananda Rock Memorial Jetty", "Kanyakumari", 8.0883, 77.5385, 2, 3, "Golden Hour Portrait", 9000, "shot", [3, 5]),
    ("Alumni Meet 2026", "Event", -6, 18, "NEC Auditorium", "Kovilpatti", 9.1731, 77.8660, 1, 6, "Event Coverage", 20000, "shot", [0, 4, 7]),
    ("Rameswaram Pre-wedding", "Wedding", 5, 6, "Dhanushkodi Beach", "Rameswaram", 9.2876, 79.3129, 0, 0, "Pre-wedding", 30000, "booked", [1, 5]),
    ("Marina Street Series", "Travel", 12, 17, "Marina Beach", "Chennai", 13.0500, 80.2824, 2, 5, "Street Series", 12000, "booked", [3, 4]),
    ("Ooty Tea Estate Shoot", "Travel", 20, 7, "Doddabetta Tea Estate", "Ooty", 11.4000, 76.7350, 2, 3, "Landscape Story", 18000, "enquiry", [1, 6]),
    ("Product Launch Studio Day", "Product", 5, 10, "PhotoNest Studio", "Kovilpatti", 9.1750, 77.8640, 3, 4, "Studio Day", 24000, "booked", [1, 7]),
    ("Mahabalipuram Portfolio Walk", "Portrait", -85, 6, "Shore Temple", "Mahabalipuram", 12.6269, 80.1927, 0, 3, "Portfolio Session", 11000, "delivered", [0, 4]),
]


def seed(store, reset=False):
    db = store.db
    if reset:
        for c in ("shoots", "clients", "photographers", "equipment"):
            db[c].delete_many({})
        for f in list(store.fs.find()):
            store.fs.delete(f._id)
    if db.photographers.count_documents({}):
        return False
    now = dt.datetime.utcnow().replace(minute=0, second=0, microsecond=0)
    ph = [{"name": n, "email": e, "specialty": s, "phone": p, "demo": True, "created_at": now} for n, e, s, p in PHOTOGRAPHERS]
    cl = [{"name": n, "email": e, "phone": p, "organisation": o, "demo": True, "created_at": now} for n, e, p, o in CLIENTS]
    eq = [{"name": n, "type": t, "serial": s, "status": st, "demo": True, "maintenance_log": [
        {"_id": secrets.token_hex(4), "date": now - dt.timedelta(days=R.randint(30, 200)), "note": "Sensor clean & firmware update", "cost": R.choice([0, 800, 1500])}
    ] if t in ("camera", "drone") else []} for n, t, s, st in EQUIPMENT]
    for coll, docs in ((db.photographers, ph), (db.clients, cl), (db.equipment, eq)):
        coll.insert_many(docs)

    for i, (title, cat, days, hour, venue, city, lat, lng, pi, ci, pkg, price, status, gear) in enumerate(SHOOTS):
        when = (now + dt.timedelta(days=days)).replace(hour=hour)
        doc = {
            "slug": f"{title.lower().replace(' ', '-').replace('&', 'and')}-{i}", "title": title, "category": cat,
            "status": status, "shoot_date": when, "duration_hours": R.choice([2, 3, 4, 6]),
            "photographer": {"id": str(ph[pi]["_id"]), "name": ph[pi]["name"], "specialty": ph[pi]["specialty"]},
            "client": {"id": str(cl[ci]["_id"]), "name": cl[ci]["name"], "email": cl[ci]["email"], "phone": cl[ci]["phone"]},
            "venue": {"name": venue, "city": city, "address": f"{venue}, {city}, Tamil Nadu"},
            "location": {"type": "Point", "coordinates": [lng, lat]},
            "package": {"name": pkg, "price": price, "currency": "INR"},
            "equipment": [{"id": str(eq[g]["_id"]), "name": eq[g]["name"], "type": eq[g]["type"]} for g in gear],
            "shot_list": [{"_id": secrets.token_hex(4), "text": t, "done": status in ("shot", "editing", "delivered")}
                          for t in ("Establishing wide shots", "Key people / subjects", "Detail shots", "Golden-hour set")],
            "payments": [], "media": [], "demo": True, "created_at": now,
            "proof": {"token": secrets.token_urlsafe(10), "enabled": True, "selections": [], "comments": []},
        }
        adv = round(price * 0.4)
        doc["payments"].append({"_id": secrets.token_hex(4), "label": "Advance (40%)", "amount": adv, "method": "UPI",
                                "status": "paid" if status != "enquiry" else "pending", "reference": f"UPI{R.randint(10**8, 10**9)}",
                                "paid_at": (when - dt.timedelta(days=10)) if status != "enquiry" else None})
        done = status == "delivered"
        doc["payments"].append({"_id": secrets.token_hex(4), "label": "Balance", "amount": price - adv,
                                "method": "Bank transfer" if done else "", "status": "paid" if done else "pending",
                                "reference": f"NEFT{R.randint(10**8, 10**9)}" if done else "",
                                "paid_at": (when + dt.timedelta(days=R.randint(3, 12))) if done else None})
        if status in ("shot", "editing", "delivered"):
            cam, lens = GEAR[pi % len(GEAR)]
            n_img = R.randint(4, 6)
            theme = {"Wedding": "rose", "Travel": "sunset", "Wildlife": "forest", "Product": "studio", "Portrait": "sunset"}.get(cat, R.choice(list(THEMES)))
            first = None
            for k in range(n_img):
                taken = when + dt.timedelta(minutes=k * 11)
                iso = R.choice([100, 100, 200, 400, 800, 1600, 3200])
                raw = fake_photo(theme if k % 3 else R.choice(list(THEMES)), i * 10 + k, cam, lens, iso, R.choice([1.4, 1.8, 2.8, 4, 5.6]),
                                 R.choice([60, 125, 250, 500, 1000]), R.choice([24, 35, 50, 85, 135]), taken,
                                 gps=(lat, lng) if k == 0 else None)
                if k == n_img - 1 and first:       # a near-duplicate frame so duplicate detection has something to find
                    raw = first
                m = mediam.ingest(store, doc, raw, f"IMG_{i:02d}{k:02d}.jpg", "image/jpeg",
                                  caption=R.choice(["Opening frame", "Candid moment", "Wide establishing shot", "Detail", "Group frame"]),
                                  tags=sorted(R.sample(TAGS[cat], 2)))
                m["rating"] = R.choice([0, 3, 4, 4, 5, 5])
                m["favorite"] = m["rating"] == 5 and R.random() < 0.7
                m["demo"] = True
                first = first or raw
                doc["media"].append(m)
            doc["media"].append(mediam.external_link("https://www.youtube.com/watch?v=aqz-KE-bpKQ", f"{cat} highlight reel (example embed)", ["reel", "video"]))
            doc["media"][-1]["demo"] = True
            if status == "delivered":
                doc["proof"]["selections"] = [m["_id"] for m in doc["media"] if m.get("favorite")]
                doc["proof"]["comments"] = [{"author": doc["client"]["name"], "text": "Love these! Please retouch the first frame.", "at": when + dt.timedelta(days=4)}]
        db.shoots.insert_one(doc)
    return True


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    import db as dbm
    st = dbm.connect()
    dbm.ensure_indexes(st.db)
    print("mode:", st.mode, "| seeded:", seed(st, reset="--reset" in sys.argv))
